# IMPULSE VISUAL — Fabric client for Minecraft 1.21.11

Versions: Minecraft 1.21.11, Fabric Loader 0.18.4, Fabric API 0.141.3+1.21.11, Yarn 1.21.11+build.4, Loom 1.14, Java 21.

## Open the menu (no keyboard)
1. Pause menu (ESC / pause button) or inventory -> tap the **IV** button in the top-left corner.
2. In-game: PojavLauncher -> Control settings -> edit layout -> add a button, label it "IV", bind it to **Right Shift**. Tap it to open the menu.

## What is real and what is limited
- Combat, ESP (2D/3D box, health bar, item, spin, skeleton), HUD and perf options are real code.
- ESP is drawn as a 2D overlay from projected world coordinates. It is first-person only. Set video option "FOV Effects" to 0, otherwise sprinting shifts the boxes slightly.
- Skeleton is a fixed pose aligned to the body direction, not the animated bones.
- KillAura/Aim Assist rotate on the client only (no silent rotations). Auto Crit works inside KillAura (jumps, hits while falling), not for manual taps.
- AutoGapple needs a golden apple in the inventory; AutoTotem swaps with a hidden inventory click.
- Shaders are NOT included: they do not run acceptably on PojavLauncher/Galaxy A17.
- Server anti-cheats detect these modules. Use on singleplayer or servers that allow it.
