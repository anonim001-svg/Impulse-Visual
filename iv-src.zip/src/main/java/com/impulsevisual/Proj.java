package com.impulsevisual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Vec3d;

/** World -> GUI-screen projection using our own camera math (no dependency on renderer internals). */
public final class Proj {
    private final Vec3d cam;
    private final double rx, rz, fx, fy, fz, ux, uy, uz, tan, aspect;
    private final int w, h;

    private Proj(Vec3d cam, float yawDeg, float pitchDeg, double fovDeg, int w, int h) {
        this.cam = cam; this.w = w; this.h = h;
        double yaw = Math.toRadians(yawDeg), pit = Math.toRadians(pitchDeg);
        fx = -Math.sin(yaw) * Math.cos(pit);
        fy = -Math.sin(pit);
        fz = Math.cos(yaw) * Math.cos(pit);
        rx = -Math.cos(yaw);
        rz = -Math.sin(yaw);
        ux = -rz * fy;
        uy = rz * fx - rx * fz;
        uz = rx * fy;
        tan = Math.tan(Math.toRadians(fovDeg) / 2.0);
        aspect = (double) w / (double) h;
    }

    public static Proj make(MinecraftClient mc, ClientPlayerEntity me, float td, int w, int h) {
        Camera cam = mc.gameRenderer.getCamera();
        Vec3d pos = me.getLerpedPos(td).add(0, me.getEyeHeight(me.getPose()), 0);
        return new Proj(pos, cam.getYaw(), cam.getPitch(), mc.options.getFov().getValue(), w, h);
    }

    /** @return {x, y} in scaled GUI coordinates, or null when behind the camera. */
    public double[] p(Vec3d v) {
        double dx = v.x - cam.x, dy = v.y - cam.y, dz = v.z - cam.z;
        double z = dx * fx + dy * fy + dz * fz;
        if (z < 0.1) return null;
        double x = dx * rx + dz * rz;
        double y = dx * ux + dy * uy + dz * uz;
        return new double[]{(x / (z * tan * aspect) * 0.5 + 0.5) * w, (0.5 - y / (z * tan) * 0.5) * h};
    }
}
