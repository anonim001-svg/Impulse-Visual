package com.impulsevisual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class Esp {
    private static final int[][] EDGES = {{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};

    public static void render(MinecraftClient mc, DrawContext c, float td) {
        if (!(Settings.BOX2D.on || Settings.BOX3D.on || Settings.SKELETON.on || Settings.HEALTHBAR.on
                || Settings.ITEM_ESP.on || Settings.SPIN_ESP.on)) return;
        ClientPlayerEntity me = mc.player;
        if (me == null || mc.world == null || !mc.options.getPerspective().isFirstPerson()) return;
        Proj pr = Proj.make(mc, me, td, c.getScaledWindowWidth(), c.getScaledWindowHeight());
        double r2 = Settings.ESP_RANGE.value * Settings.ESP_RANGE.value;
        for (Entity e : mc.world.getEntities()) {
            if (e == me) continue;
            if (e instanceof PlayerEntity pl) {
                if (pl.isSpectator() || me.squaredDistanceTo(e) > r2) continue;
                player(c, pr, pl, td);
            } else if (e instanceof ItemEntity it && Settings.ITEM_ESP.on) {
                if (me.squaredDistanceTo(e) > Math.min(r2, 2304.0)) continue;
                item(mc, c, pr, it, td);
            }
        }
    }

    private static void player(DrawContext c, Proj pr, PlayerEntity pl, float td) {
        Vec3d pos = pl.getLerpedPos(td);
        Box b = pl.getDimensions(pl.getPose()).getBoxAt(pos);
        double hgt = b.maxY - b.minY;
        Vec3d[] cr = {
            new Vec3d(b.minX, b.minY, b.minZ), new Vec3d(b.maxX, b.minY, b.minZ),
            new Vec3d(b.maxX, b.minY, b.maxZ), new Vec3d(b.minX, b.minY, b.maxZ),
            new Vec3d(b.minX, b.maxY, b.minZ), new Vec3d(b.maxX, b.maxY, b.minZ),
            new Vec3d(b.maxX, b.maxY, b.maxZ), new Vec3d(b.minX, b.maxY, b.maxZ)};
        double[][] s = new double[8][];
        double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
        boolean ok = true;
        for (int i = 0; i < 8; i++) {
            s[i] = pr.p(cr[i]);
            if (s[i] == null) { ok = false; break; }
            minX = Math.min(minX, s[i][0]); maxX = Math.max(maxX, s[i][0]);
            minY = Math.min(minY, s[i][1]); maxY = Math.max(maxY, s[i][1]);
        }
        if (ok) {
            if (Settings.BOX2D.on) Draw.outline(c, (int) minX, (int) minY, (int) maxX, (int) maxY, Draw.PURPLE);
            if (Settings.BOX3D.on) {
                for (int[] ed : EDGES) Draw.line(c, s[ed[0]][0], s[ed[0]][1], s[ed[1]][0], s[ed[1]][1], Draw.VIOLET);
            }
            if (Settings.HEALTHBAR.on) {
                float frac = MathHelper.clamp((pl.getHealth() + pl.getAbsorptionAmount()) / pl.getMaxHealth(), 0f, 1f);
                int bx = (int) minX - 5, top = (int) minY, bot = (int) maxY;
                c.fill(bx - 1, top - 1, bx + 2, bot + 2, 0xFF000000);
                int fh = (int) ((bot - top) * frac);
                c.fill(bx, bot - fh, bx + 1, bot, Draw.hpColor(frac));
            }
        }
        if (Settings.SKELETON.on) skeleton(c, pr, pl, pos, hgt);
        if (Settings.SPIN_ESP.on) spin(c, pr, pos, hgt);
    }

    private static Vec3d at(Vec3d base, double rx, double rz, double side, double y) {
        return base.add(rx * side, y, rz * side);
    }

    private static void seg(DrawContext c, Proj pr, Vec3d a, Vec3d b, int col) {
        double[] p = pr.p(a), q = pr.p(b);
        if (p == null || q == null) return;
        Draw.line(c, p[0], p[1], q[0], q[1], col);
    }

    /** Fixed-pose skeleton aligned to the body yaw (real bone animation is not exposed outside the model renderer). */
    private static void skeleton(DrawContext c, Proj pr, PlayerEntity pl, Vec3d pos, double hgt) {
        double s = hgt / 1.8;
        double yaw = Math.toRadians(pl.getBodyYaw());
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);
        int col = 0xFFFFFFFF;
        Vec3d hip = at(pos, rx, rz, 0, 0.75 * s), neck = at(pos, rx, rz, 0, 1.4 * s), head = at(pos, rx, rz, 0, 1.75 * s);
        Vec3d lSh = at(pos, rx, rz, -0.3, 1.4 * s), rSh = at(pos, rx, rz, 0.3, 1.4 * s);
        Vec3d lHand = at(pos, rx, rz, -0.36, 0.8 * s), rHand = at(pos, rx, rz, 0.36, 0.8 * s);
        Vec3d lHip = at(pos, rx, rz, -0.12, 0.75 * s), rHip = at(pos, rx, rz, 0.12, 0.75 * s);
        Vec3d lFoot = at(pos, rx, rz, -0.12, 0), rFoot = at(pos, rx, rz, 0.12, 0);
        seg(c, pr, neck, hip, col); seg(c, pr, neck, head, col);
        seg(c, pr, lSh, rSh, col); seg(c, pr, lSh, lHand, col); seg(c, pr, rSh, rHand, col);
        seg(c, pr, lHip, rHip, col); seg(c, pr, lHip, lFoot, col); seg(c, pr, rHip, rFoot, col);
    }

    /** Rotating open square (gaps in every side) drawn in world space around the player's waist. */
    private static void spin(DrawContext c, Proj pr, Vec3d pos, double hgt) {
        Vec3d center = pos.add(0, hgt * 0.5, 0);
        double a = (System.currentTimeMillis() % 3000L) / 3000.0 * Math.PI * 2.0;
        double rad = 0.85 * 1.41421356;
        Vec3d[] q = new Vec3d[4];
        for (int k = 0; k < 4; k++) {
            double ang = a + Math.PI / 4 + k * Math.PI / 2;
            q[k] = center.add(Math.cos(ang) * rad, 0, Math.sin(ang) * rad);
        }
        for (int k = 0; k < 4; k++) {
            Vec3d p0 = q[k], p1 = q[(k + 1) % 4];
            seg(c, pr, p0.lerp(p1, 0.10), p0.lerp(p1, 0.65), Draw.PURPLE);
        }
    }

    private static void item(MinecraftClient mc, DrawContext c, Proj pr, ItemEntity it, float td) {
        double[] s = pr.p(it.getLerpedPos(td).add(0, 0.2, 0));
        if (s == null) return;
        int x = (int) s[0], y = (int) s[1];
        Draw.outline(c, x - 4, y - 4, x + 4, y + 4, 0xFFE879F9);
        String name = it.getStack().getName().getString();
        if (name.length() > 22) name = name.substring(0, 22);
        String label = name + (it.getStack().getCount() > 1 ? " x" + it.getStack().getCount() : "");
        c.drawText(mc.textRenderer, label, x - mc.textRenderer.getWidth(label) / 2, y - 14, 0xFFF5D0FE, true);
    }
    private Esp() { }
}
