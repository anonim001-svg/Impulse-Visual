package com.impulsevisual;

import com.impulsevisual.mixin.HandledScreenAccessor;
import net.minecraft.block.Block;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;

import java.util.List;

public final class ShulkerPreview {
    public static void draw(MinecraftClient mc, DrawContext c, Screen screen, int mx, int my) {
        if (!Settings.SHULKER.on || !(screen instanceof HandledScreen<?>)) return;
        Slot slot = ((HandledScreenAccessor) (Object) screen).iv$getFocusedSlot();
        if (slot == null || !slot.hasStack()) return;
        ItemStack st = slot.getStack();
        if (!(Block.getBlockFromItem(st.getItem()) instanceof ShulkerBoxBlock)) return;
        ContainerComponent comp = st.get(DataComponentTypes.CONTAINER);
        if (comp == null) return;
        List<ItemStack> items = comp.streamNonEmpty().toList();
        int w = 9 * 18 + 8, h = 3 * 18 + 8;
        int x = Math.min(mx + 12, c.getScaledWindowWidth() - w - 2);
        int y = Math.max(2, Math.min(my - h - 6, c.getScaledWindowHeight() - h - 2));
        Draw.panel(c, x, y, w, h, 1f);
        for (int i = 0; i < 27; i++) {
            int sx = x + 4 + (i % 9) * 18, sy = y + 4 + (i / 9) * 18;
            c.fill(sx, sy, sx + 17, sy + 17, 0x60301050);
        }
        for (int i = 0; i < items.size() && i < 27; i++) {
            int sx = x + 4 + (i % 9) * 18 + 1, sy = y + 4 + (i / 9) * 18 + 1;
            c.drawItem(items.get(i), sx, sy);
            c.drawStackOverlay(mc.textRenderer, items.get(i), sx, sy);
        }
    }
    private ShulkerPreview() { }
}
