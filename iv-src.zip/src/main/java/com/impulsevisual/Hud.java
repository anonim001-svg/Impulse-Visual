package com.impulsevisual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class Hud {
    private static float hpAnim, tAnim;
    private static LivingEntity shown;

    public static void render(MinecraftClient mc, DrawContext c, float td) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;
        int w = c.getScaledWindowWidth(), h = c.getScaledWindowHeight();

        // ---- info panel (CPS / Combo / Reach) ----
        List<String> lines = new ArrayList<>();
        if (Settings.CPS.on) lines.add("CPS  " + Combat.cps());
        if (Settings.COMBO.on) lines.add("Combo  " + Combat.combo);
        if (Settings.REACH.on) lines.add("Reach  " + (Combat.lastReach > 0 ? String.format(Locale.ROOT, "%.2f", Combat.lastReach) : "-"));
        int y = 6;
        if (!lines.isEmpty()) {
            int ph = 6 + lines.size() * 10;
            Draw.panel(c, 6, y, 62, ph, 1f);
            for (int i = 0; i < lines.size(); i++) c.drawText(tr, lines.get(i), 11, y + 4 + i * 10, Draw.TEXT, false);
            y += ph + 4;
        }

        // ---- totem / gapple counters ----
        if (Settings.COUNTERS.on) {
            int totems = 0, gapples = 0;
            for (int i = 0; i < p.getInventory().size(); i++) {
                ItemStack s = p.getInventory().getStack(i);
                if (s.isOf(Items.TOTEM_OF_UNDYING)) totems += s.getCount();
                else if (s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.ENCHANTED_GOLDEN_APPLE)) gapples += s.getCount();
            }
            Draw.panel(c, 6, y, 62, 36, 1f);
            c.drawItem(new ItemStack(Items.TOTEM_OF_UNDYING), 10, y + 2);
            c.drawText(tr, "x" + totems, 30, y + 6, Draw.TEXT, false);
            c.drawItem(new ItemStack(Items.GOLDEN_APPLE), 10, y + 18);
            c.drawText(tr, "x" + gapples, 30, y + 22, Draw.TEXT, false);
            y += 40;
        }

        // ---- armor status, left of the hotbar ----
        if (Settings.ARMOR.on) {
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            int ax = w / 2 - 91 - 34 - 4 * 18, ay = h - 20;
            for (int i = 0; i < 4; i++) {
                ItemStack s = p.getEquippedStack(slots[i]);
                int x = ax + i * 18;
                c.fill(x, ay, x + 17, ay + 17, 0x90100820);
                if (s.isEmpty()) continue;
                c.drawItem(s, x + 1, ay + 1);
                if (s.isDamageable()) {
                    float f = 1f - (float) s.getDamage() / (float) s.getMaxDamage();
                    c.fill(x + 1, ay + 15, x + 16, ay + 17, 0xFF000000);
                    c.fill(x + 1, ay + 15, x + 1 + (int) (15 * f), ay + 16, Draw.hpColor(f));
                }
            }
        }

        // ---- inventory item counts ----
        if (Settings.INV_COUNT.on) {
            Map<Item, Integer> map = new HashMap<>();
            for (int i = 0; i < 36; i++) {
                ItemStack s = p.getInventory().getStack(i);
                if (!s.isEmpty()) map.merge(s.getItem(), s.getCount(), Integer::sum);
            }
            List<Map.Entry<Item, Integer>> list = new ArrayList<>(map.entrySet());
            list.sort((a, b) -> b.getValue() - a.getValue());
            int n = Math.min(6, list.size());
            if (n > 0) {
                int px = w - 58, py = 6;
                Draw.panel(c, px, py, 52, 4 + n * 17, 1f);
                for (int i = 0; i < n; i++) {
                    c.drawItem(new ItemStack(list.get(i).getKey()), px + 3, py + 3 + i * 17);
                    c.drawText(tr, String.valueOf(list.get(i).getValue()), px + 23, py + 7 + i * 17, Draw.TEXT, false);
                }
            }
        }

        // ---- keystrokes ----
        if (Settings.KEYSTROKES.on) {
            int kx = w - 78, ky = h / 2 - 20, s = 20;
            key(c, tr, kx + s + 2, ky, s, "W", mc.options.forwardKey.isPressed());
            key(c, tr, kx, ky + s + 2, s, "A", mc.options.leftKey.isPressed());
            key(c, tr, kx + s + 2, ky + s + 2, s, "S", mc.options.backKey.isPressed());
            key(c, tr, kx + 2 * (s + 2), ky + s + 2, s, "D", mc.options.rightKey.isPressed());
            int bw = (3 * s + 4 - 2) / 2;
            keyW(c, tr, kx, ky + 2 * (s + 2), bw, 16, "LMB", mc.options.attackKey.isPressed());
            keyW(c, tr, kx + bw + 2, ky + 2 * (s + 2), bw, 16, "RMB", mc.options.useKey.isPressed());
        }

        // ---- Target HUD ----
        if (Settings.TARGET_HUD.on) {
            LivingEntity t = Combat.auraTarget != null ? Combat.auraTarget
                    : Combat.aimTarget != null ? Combat.aimTarget
                    : (mc.targetedEntity instanceof LivingEntity le ? le : null);
            if (t != null) shown = t;
            tAnim += ((t != null ? 1f : 0f) - tAnim) * 0.2f;
            if (tAnim < 0.03f) { shown = null; return; }
            if (shown == null) return;
            float hp = shown.getHealth(), max = shown.getMaxHealth();
            hpAnim += (hp - hpAnim) * 0.2f;
            int tx = w / 2 + 16, ty = h / 2 + 16 + (int) ((1f - tAnim) * 8);
            Draw.panel(c, tx, ty, 108, 32, tAnim);
            String name = shown.getName().getString();
            if (name.length() > 16) name = name.substring(0, 16);
            c.drawText(tr, name, tx + 6, ty + 5, Draw.alpha(Draw.TEXT, tAnim), false);
            String hpText = String.format(Locale.ROOT, "%.1f", hp);
            c.drawText(tr, hpText, tx + 108 - 6 - tr.getWidth(hpText), ty + 5, Draw.alpha(Draw.hpColor(hp / max), tAnim), false);
            c.fill(tx + 6, ty + 20, tx + 102, ty + 25, Draw.alpha(0xFF1F1030, tAnim));
            float frac = MathHelper.clamp(hpAnim / max, 0f, 1f);
            c.fill(tx + 6, ty + 20, tx + 6 + (int) (96 * frac), ty + 25, Draw.alpha(Draw.hpColor(frac), tAnim));
        }
    }

    private static void key(DrawContext c, TextRenderer tr, int x, int y, int s, String l, boolean down) {
        keyW(c, tr, x, y, s, s, l, down);
    }

    private static void keyW(DrawContext c, TextRenderer tr, int x, int y, int w, int h, String l, boolean down) {
        c.fill(x, y, x + w, y + h, down ? 0xE0A855F7 : 0xB00C0612);
        Draw.outline(c, x, y, x + w - 1, y + h - 1, 0xFF5B21B6);
        c.drawText(tr, l, x + (w - tr.getWidth(l)) / 2, y + (h - 8) / 2, down ? 0xFF000000 : Draw.TEXT, false);
    }
    private Hud() { }
}
