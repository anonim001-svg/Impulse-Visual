package com.impulsevisual;

import java.util.Locale;

public final class Setting {
    public enum Kind { BOOL, NUM, ACTION }

    public final Kind kind;
    public final String key, label, tab;
    public final double min, max, step;
    public boolean on;
    public double value;
    public float anim;
    public Runnable onChange = () -> {};
    public Runnable action = () -> {};

    Setting(Kind kind, String key, String label, String tab, double def, double min, double max, double step) {
        this.kind = kind; this.key = key; this.label = label; this.tab = tab;
        this.min = min; this.max = max; this.step = step;
        this.value = def;
        this.on = kind == Kind.BOOL && def != 0;
        this.anim = on ? 1f : 0f;
    }

    public Setting changed(Runnable r) { this.onChange = r; return this; }

    public String valueText() {
        if (step >= 1) return String.valueOf((int) Math.round(value));
        return String.format(Locale.ROOT, "%.2f", value);
    }
}
