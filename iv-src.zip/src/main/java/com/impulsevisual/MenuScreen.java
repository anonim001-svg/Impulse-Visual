package com.impulsevisual;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Touch menu. Input is read by polling the GLFW mouse button (PojavLauncher emulates it from touches),
 * so it does not depend on Screen click method signatures.
 */
public final class MenuScreen extends Screen {
    private static final int ROW = 20, HEAD = 40;
    private final Screen parent;
    private int tab, px, py, pw, ph;
    private float tabX, open, scroll;
    private boolean first = true, wasDown, dragSlider, dragScroll, moved;
    private Setting active, pressRow;
    private double lastY, pressY;

    public MenuScreen(Screen parent) {
        super(Text.literal("IMPULSE VISUAL"));
        this.parent = parent;
    }

    @Override protected void init() {
        pw = Math.min(width - 12, 300);
        ph = Math.min(height - 12, 230);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
    }

    @Override public boolean shouldPause() { return false; }

    @Override public void close() {
        Settings.save();
        client.setScreen(parent);
    }

    private List<Setting> rows() {
        List<Setting> l = new ArrayList<>();
        for (Setting s : Settings.ALL) if (s.tab.equals(Settings.TABS[tab])) l.add(s);
        return l;
    }

    private double trackX0() { return px + pw * 0.46; }
    private double trackX1() { return px + pw - 46; }

    private void setSlider(Setting s, double mx) {
        double f = Math.max(0, Math.min(1, (mx - trackX0()) / (trackX1() - trackX0())));
        double v = s.min + f * (s.max - s.min);
        v = Math.round(v / s.step) * s.step;
        s.value = Math.max(s.min, Math.min(s.max, v));
    }

    private float maxScroll() {
        return Math.max(0, rows().size() * ROW - (ph - HEAD - 6));
    }

    private void press(int mx, int my) {
        moved = false; pressY = my; lastY = my;
        active = null; pressRow = null; dragSlider = false; dragScroll = false;
        if (mx < px || mx > px + pw || my < py || my > py + ph) { close(); return; }
        if (my < py + 22 && mx > px + pw - 24) { close(); return; }
        if (my >= py + 22 && my < py + HEAD - 4) {
            int t = (mx - px) / (pw / 4);
            if (t >= 0 && t < 4) { tab = t; scroll = 0; }
            return;
        }
        int top = py + HEAD;
        if (my >= top) {
            List<Setting> l = rows();
            int i = (int) ((my - top + scroll) / ROW);
            if (i >= 0 && i < l.size()) {
                Setting s = l.get(i);
                if (s.kind == Setting.Kind.NUM && mx >= px + pw * 0.40) {
                    active = s; dragSlider = true; setSlider(s, mx);
                } else pressRow = s;
            }
            dragScroll = !dragSlider;
        }
    }

    private void drag(int mx, int my) {
        if (dragSlider && active != null) { setSlider(active, mx); return; }
        if (dragScroll) {
            if (Math.abs(my - pressY) > 4) moved = true;
            if (moved) scroll = Math.max(0, Math.min(maxScroll(), (float) (scroll - (my - lastY))));
        }
        lastY = my;
    }

    private void release() {
        if (dragSlider && active != null) {
            active.onChange.run();
            Settings.save();
        } else if (pressRow != null && !moved) {
            Setting s = pressRow;
            if (s.kind == Setting.Kind.BOOL) {
                s.on = !s.on; s.value = s.on ? 1 : 0;
                s.onChange.run();
                Settings.save();
            } else if (s.kind == Setting.Kind.ACTION) s.action.run();
        }
        active = null; pressRow = null; dragSlider = false; dragScroll = false;
    }

    @Override public void render(DrawContext c, int mx, int my, float delta) {
        long win = client.getWindow().getHandle();
        boolean down = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        if (first) { wasDown = down; first = false; }
        if (down && !wasDown) press(mx, my);
        else if (down) drag(mx, my);
        else if (wasDown) release();
        wasDown = down;

        open += (1f - open) * 0.2f;
        float tw = pw / 4f;
        tabX += (tab * tw - tabX) * 0.3f;
        scroll = Math.max(0, Math.min(maxScroll(), scroll));

        c.fill(0, 0, width, height, Draw.alpha(0xB0000000, open));
        c.fill(px, py, px + pw, py + ph, Draw.alpha(0xF00C0612, open));
        Draw.outline(c, px, py, px + pw - 1, py + ph - 1, Draw.alpha(0xFF5B21B6, open));
        c.fillGradient(px + 1, py + 1, px + pw - 1, py + 22, 0xFF3B1470, 0xFF140A24);
        c.drawText(textRenderer, "IMPULSE VISUAL", px + 8, py + 7, Draw.TEXT, true);
        c.drawText(textRenderer, "X", px + pw - 14, py + 7, 0xFFC084FC, true);

        for (int i = 0; i < 4; i++) {
            String t = Settings.TABS[i];
            int cx = (int) (px + i * tw + tw / 2f);
            c.drawText(textRenderer, t, cx - textRenderer.getWidth(t) / 2, py + 27, i == tab ? 0xFFFFFFFF : 0xFF9B7BC8, false);
        }
        c.fill((int) (px + tabX) + 6, py + 37, (int) (px + tabX + tw) - 6, py + 39, Draw.PURPLE);

        int top = py + HEAD, bottom = py + ph - 4;
        c.enableScissor(px + 1, top, px + pw - 1, bottom);
        List<Setting> l = rows();
        for (int i = 0; i < l.size(); i++) {
            Setting s = l.get(i);
            int ry = top + i * ROW - (int) scroll;
            if (ry + ROW < top || ry > bottom) continue;
            if (i % 2 == 0) c.fill(px + 4, ry, px + pw - 4, ry + ROW - 1, 0x18A855F7);
            c.drawText(textRenderer, s.label, px + 10, ry + 6, Draw.TEXT, false);
            if (s.kind == Setting.Kind.BOOL) {
                s.anim += ((s.on ? 1f : 0f) - s.anim) * 0.3f;
                int bx = px + pw - 40, by = ry + 5;
                c.fill(bx, by, bx + 28, by + 10, Draw.lerpColor(0xFF2A2238, Draw.PURPLE, s.anim));
                int kx = bx + 1 + (int) (s.anim * 18);
                c.fill(kx, by + 1, kx + 8, by + 9, 0xFFFFFFFF);
            } else if (s.kind == Setting.Kind.NUM) {
                int x0 = (int) trackX0(), x1 = (int) trackX1(), cy = ry + 10;
                float f = (float) ((s.value - s.min) / (s.max - s.min));
                c.fill(x0, cy - 1, x1, cy + 1, 0xFF2A2238);
                int kx = x0 + (int) ((x1 - x0) * f);
                c.fill(x0, cy - 1, kx, cy + 1, Draw.PURPLE);
                c.fill(kx - 2, cy - 5, kx + 3, cy + 5, 0xFFFFFFFF);
                c.drawText(textRenderer, s.valueText(), x1 + 7, ry + 6, Draw.VIOLET, false);
            } else {
                int bx = px + pw - 70;
                c.fill(bx, ry + 3, bx + 60, ry + ROW - 4, Draw.PURPLE);
                String t = "Apply";
                c.drawText(textRenderer, t, bx + (60 - textRenderer.getWidth(t)) / 2, ry + 6, 0xFFFFFFFF, false);
            }
        }
        c.disableScissor();
        if (maxScroll() > 0) {
            int vh = bottom - top;
            int bh = Math.max(14, (int) (vh * vh / (float) (vh + maxScroll())));
            int by = top + (int) ((vh - bh) * (scroll / maxScroll()));
            c.fill(px + pw - 3, by, px + pw - 1, by + bh, 0xFF7C3AED);
        }
    }
}
