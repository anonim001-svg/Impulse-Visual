package com.impulsevisual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

/** Applies real vanilla video options (these are the only safe FPS levers without rewriting the renderer). */
public final class Perf {
    public static void apply() {
        MinecraftClient mc = MinecraftClient.getInstance();
        GameOptions o = mc == null ? null : mc.options;
        if (o == null) return;
        o.getViewDistance().setValue((int) Settings.RENDER_DIST.value);
        o.getSimulationDistance().setValue((int) Settings.SIM_DIST.value);
        o.getEntityDistanceScaling().setValue(Settings.ENTITY_DIST.value);
        o.getParticles().setValue(Settings.PARTICLES_MIN.on ? ParticlesMode.MINIMAL : ParticlesMode.ALL);
        o.getMaxFps().setValue((int) Settings.MAX_FPS.value);
        o.getEntityShadows().setValue(!Settings.SHADOWS_OFF.on);
        o.getGraphicsMode().setValue(Settings.FAST_GFX.on ? GraphicsMode.FAST : GraphicsMode.FANCY);
        o.getBiomeBlendRadius().setValue(Settings.FAST_GFX.on ? 0 : 2);
        o.write();
    }
    private Perf() { }
}
