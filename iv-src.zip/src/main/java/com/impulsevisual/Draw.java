package com.impulsevisual;

import net.minecraft.client.gui.DrawContext;

public final class Draw {
    public static final int PURPLE = 0xFFA855F7;
    public static final int VIOLET = 0xFFC084FC;
    public static final int DARK = 0xE60C0612;
    public static final int TEXT = 0xFFE9D5FF;

    public static int alpha(int color, float a) {
        int al = (int) (((color >>> 24) & 0xFF) * Math.max(0f, Math.min(1f, a)));
        return (al << 24) | (color & 0xFFFFFF);
    }

    public static int lerpColor(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    public static int hpColor(float frac) {
        return lerpColor(0xFFEF4444, 0xFF22C55E, Math.max(0f, Math.min(1f, frac)));
    }

    public static void outline(DrawContext c, int x1, int y1, int x2, int y2, int col) {
        c.fill(x1, y1, x2 + 1, y1 + 1, col);
        c.fill(x1, y2, x2 + 1, y2 + 1, col);
        c.fill(x1, y1, x1 + 1, y2 + 1, col);
        c.fill(x2, y1, x2 + 1, y2 + 1, col);
    }

    public static void panel(DrawContext c, int x, int y, int w, int h, float a) {
        c.fill(x, y, x + w, y + h, alpha(DARK, a));
        outline(c, x, y, x + w - 1, y + h - 1, alpha(0xFF5B21B6, a));
        c.fill(x, y, x + w, y + 1, alpha(PURPLE, a));
    }

    /** Line drawn as 1-GUI-pixel dots. DrawContext has no line primitive in 1.21.11. */
    public static void line(DrawContext c, double x1, double y1, double x2, double y2, int col) {
        int w = c.getScaledWindowWidth(), h = c.getScaledWindowHeight();
        if ((x1 < 0 && x2 < 0) || (y1 < 0 && y2 < 0) || (x1 > w && x2 > w) || (y1 > h && y2 > h)) return;
        double dx = x2 - x1, dy = y2 - y1;
        int n = (int) Math.min(Math.max(Math.abs(dx), Math.abs(dy)), 1200);
        if (n < 1) { c.fill((int) x1, (int) y1, (int) x1 + 1, (int) y1 + 1, col); return; }
        for (int i = 0; i <= n; i++) {
            int x = (int) (x1 + dx * i / n), y = (int) (y1 + dy * i / n);
            if (x < 0 || y < 0 || x >= w || y >= h) continue;
            c.fill(x, y, x + 1, y + 1, col);
        }
    }
    private Draw() { }
}
