package com.impulsevisual;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.entity.LivingEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class ImpulseVisual implements ClientModInitializer {
    private static boolean wasKey;

    @Override
    public void onInitializeClient() {
        Settings.load();

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            Combat.tick(mc);
            // Menu hotkey: Right Shift. In PojavLauncher map an on-screen button to "Right Shift" and label it "IV".
            if (mc.getWindow() != null) {
                boolean down = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
                if (down && !wasKey && mc.currentScreen == null && mc.player != null) mc.setScreen(new MenuScreen(null));
                wasKey = down;
            }
        });

        HudElementRegistry.addLast(Identifier.of("impulsevisual", "main"), (ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            float td = tickCounter.getTickProgress(false);
            Esp.render(mc, ctx, td);
            Hud.render(mc, ctx, td);
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient() && entity instanceof LivingEntity) Combat.recordHit(player, entity);
            return ActionResult.PASS;
        });

        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            boolean inv = screen instanceof HandledScreen<?>;
            if (screen instanceof GameMenuScreen || inv) {
                Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("IV"),
                        b -> client.setScreen(new MenuScreen(screen))).dimensions(4, 4, 28, 16).build());
            }
            if (inv) {
                ScreenEvents.afterRender(screen).register((s, ctx, mx, my, d) -> ShulkerPreview.draw(client, ctx, s, mx, my));
            }
        });
    }
}
