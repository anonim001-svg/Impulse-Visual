package com.impulsevisual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.Deque;

public final class Combat {
    public static LivingEntity auraTarget, aimTarget;
    public static int combo;
    public static double lastReach;
    private static long lastHitMs;

    private static final Deque<Long> clicks = new ArrayDeque<>();
    private static boolean wasAttack, wasHurt, jumpForced, eating;
    private static int totemDelay, eatTicks, prevSlot = -1;

    public static int cps() {
        long now = System.currentTimeMillis();
        while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000) clicks.pollFirst();
        return clicks.size();
    }

    public static void recordHit(PlayerEntity p, Entity e) {
        combo++;
        lastHitMs = System.currentTimeMillis();
        lastReach = reachDist(p.getEyePos(), e);
    }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) { auraTarget = aimTarget = null; return; }

        boolean atk = mc.options.attackKey.isPressed();
        if (atk && !wasAttack) clicks.addLast(System.currentTimeMillis());
        wasAttack = atk;

        boolean hurt = p.hurtTime > 0;
        if (hurt && !wasHurt) combo = 0;
        wasHurt = hurt;
        if (System.currentTimeMillis() - lastHitMs > 4000) combo = 0;

        if (jumpForced) { mc.options.jumpKey.setPressed(false); jumpForced = false; }
        if (mc.currentScreen != null || p.isSpectator()) { auraTarget = aimTarget = null; return; }

        autoTotem(mc, p);
        autoGapple(mc, p);

        auraTarget = Settings.KILLAURA.on ? find(mc, p, Settings.KA_RANGE.value) : null;
        aimTarget = Settings.AIM_ASSIST.on ? find(mc, p, Settings.AIM_RANGE.value) : null;
        LivingEntity t = auraTarget != null ? auraTarget : aimTarget;

        if (!eating && Settings.AUTO_SWAP.on && t != null) autoSwap(p);
        if (auraTarget != null && !eating) killAura(mc, p, auraTarget);
        if (aimTarget != null && !eating) aim(mc, p, aimTarget);
    }

    // ---------- targeting ----------
    public static double reachDist(Vec3d eye, Entity e) {
        Box b = e.getBoundingBox();
        double x = MathHelper.clamp(eye.x, b.minX, b.maxX);
        double y = MathHelper.clamp(eye.y, b.minY, b.maxY);
        double z = MathHelper.clamp(eye.z, b.minZ, b.maxZ);
        return eye.distanceTo(new Vec3d(x, y, z));
    }

    private static boolean inFov(PlayerEntity p, Entity e, double fov) {
        if (fov >= 360) return true;
        Vec3d eye = p.getEyePos();
        double dx = e.getX() - eye.x, dz = e.getZ() - eye.z;
        float yawT = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        return Math.abs(MathHelper.wrapDegrees(yawT - p.getYaw())) <= fov / 2.0;
    }

    private static LivingEntity find(MinecraftClient mc, ClientPlayerEntity p, double range) {
        LivingEntity best = null;
        double bestKey = Double.MAX_VALUE;
        Vec3d eye = p.getEyePos();
        for (Entity e : mc.world.getEntities()) {
            if (e == p || !(e instanceof LivingEntity le) || !le.isAlive() || le instanceof ArmorStandEntity) continue;
            if (le instanceof PlayerEntity pe) { if (pe.isSpectator()) continue; }
            else if (!Settings.TARGET_MOBS.on) continue;
            double d = reachDist(eye, le);
            if (d > range) continue;
            if (!Settings.THROUGH_WALLS.on && !p.canSee(le)) continue;
            if (!inFov(p, le, Settings.FOV.value)) continue;
            double key = Settings.LOWEST_HP.on ? le.getHealth() + le.getAbsorptionAmount() : d;
            if (key < bestKey) { bestKey = key; best = le; }
        }
        return best;
    }

    // ---------- KillAura / Auto Crit ----------
    private static void killAura(MinecraftClient mc, ClientPlayerEntity p, LivingEntity t) {
        float cd = p.getAttackCooldownProgress(0.5f);
        if (Settings.AUTO_CRIT.on) {
            if (p.isOnGround() && cd > 0.9f) { mc.options.jumpKey.setPressed(true); jumpForced = true; return; }
            boolean canCrit = !p.isOnGround() && p.fallDistance > 0.0 && !p.isClimbing()
                    && !p.isTouchingWater() && !p.hasVehicle() && !p.hasStatusEffect(StatusEffects.BLINDNESS);
            if (!canCrit) return;
        }
        if (cd < 0.92f) return;
        mc.interactionManager.attackEntity(p, t);
        p.swingHand(Hand.MAIN_HAND);
        clicks.addLast(System.currentTimeMillis());
    }

    // ---------- Aim Assist ----------
    private static void aim(MinecraftClient mc, ClientPlayerEntity p, LivingEntity t) {
        if (Settings.AIM_ONLY_ATTACK.on && !mc.options.attackKey.isPressed()) return;
        Vec3d eye = p.getEyePos();
        double dx = t.getX() - eye.x, dy = (t.getY() + t.getHeight() * 0.75) - eye.y, dz = t.getZ() - eye.z;
        double hd = Math.sqrt(dx * dx + dz * dz);
        float yawT = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitT = (float) -Math.toDegrees(Math.atan2(dy, hd));
        float sp = (float) Settings.AIM_SPEED.value;
        float dYaw = MathHelper.wrapDegrees(yawT - p.getYaw());
        float dPit = pitT - p.getPitch();
        p.setYaw(p.getYaw() + MathHelper.clamp(dYaw * 0.4f, -sp, sp));
        p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(dPit * 0.4f, -sp, sp), -90f, 90f));
    }

    // ---------- AutoTotem ----------
    private static void autoTotem(MinecraftClient mc, ClientPlayerEntity p) {
        if (!Settings.AUTO_TOTEM.on) return;
        if (totemDelay > 0) { totemDelay--; return; }
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        for (int i = 0; i < 36; i++) {
            if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                int slot = i < 9 ? 36 + i : i; // inventory index -> player screen-handler slot
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);
                totemDelay = 4;
                return;
            }
        }
    }

    // ---------- AutoGapple ----------
    private static boolean isGapple(ItemStack s) {
        return s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.ENCHANTED_GOLDEN_APPLE);
    }

    private static void stopEating(MinecraftClient mc, ClientPlayerEntity p) {
        if (!eating) return;
        eating = false;
        mc.options.useKey.setPressed(false);
        if (prevSlot >= 0) { p.getInventory().setSelectedSlot(prevSlot); prevSlot = -1; }
    }

    private static void autoGapple(MinecraftClient mc, ClientPlayerEntity p) {
        if (!Settings.AUTO_GAPPLE.on) { stopEating(mc, p); return; }
        if (eating) {
            eatTicks++;
            boolean done = eatTicks > 6 && !p.isUsingItem();
            if (done || eatTicks > 70 || p.getHealth() > Settings.GAPPLE_HP.value + 4) { stopEating(mc, p); return; }
            mc.options.useKey.setPressed(true);
            return;
        }
        if (p.getHealth() > Settings.GAPPLE_HP.value || p.isUsingItem()) return;
        int cur = p.getInventory().getSelectedSlot();
        int hot = -1;
        for (int i = 0; i < 9; i++) if (isGapple(p.getInventory().getStack(i))) { hot = i; break; }
        if (hot < 0) {
            for (int i = 9; i < 36; i++) {
                if (isGapple(p.getInventory().getStack(i))) {
                    mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, i, cur, SlotActionType.SWAP, p);
                    hot = cur;
                    break;
                }
            }
        }
        if (hot < 0) return;
        prevSlot = cur;
        p.getInventory().setSelectedSlot(hot);
        eating = true; eatTicks = 0;
        mc.options.useKey.setPressed(true);
    }

    // ---------- AutoSwap ----------
    private static int rank(ItemStack s) {
        if (s.isEmpty()) return -1;
        int base;
        if (s.isIn(ItemTags.SWORDS)) base = 100;
        else if (s.isIn(ItemTags.AXES)) base = 50;
        else return 0;
        String id = Registries.ITEM.getId(s.getItem()).getPath();
        int tier = id.startsWith("netherite") ? 6 : id.startsWith("diamond") ? 5 : id.startsWith("iron") ? 4
                : id.startsWith("copper") ? 3 : id.startsWith("stone") ? 2 : id.startsWith("golden") ? 1 : 0;
        return base + tier;
    }

    private static void autoSwap(ClientPlayerEntity p) {
        int best = -1, bestRank = -1;
        for (int i = 0; i < 9; i++) {
            int r = rank(p.getInventory().getStack(i));
            if (r > bestRank) { bestRank = r; best = i; }
        }
        int cur = p.getInventory().getSelectedSlot();
        if (best >= 0 && best != cur && bestRank > rank(p.getInventory().getStack(cur))) {
            p.getInventory().setSelectedSlot(best);
        }
    }
    private Combat() { }
}
