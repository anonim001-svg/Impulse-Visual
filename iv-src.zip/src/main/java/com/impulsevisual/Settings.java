package com.impulsevisual;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public final class Settings {
    public static final List<Setting> ALL = new ArrayList<>();
    public static final String[] TABS = {"Combat", "ESP", "HUD", "Perf"};

    private static Setting b(String key, String label, String tab, boolean def) {
        Setting s = new Setting(Setting.Kind.BOOL, key, label, tab, def ? 1 : 0, 0, 1, 1);
        ALL.add(s); return s;
    }
    private static Setting n(String key, String label, String tab, double def, double min, double max, double step) {
        Setting s = new Setting(Setting.Kind.NUM, key, label, tab, def, min, max, step);
        ALL.add(s); return s;
    }
    private static Setting a(String key, String label, String tab, Runnable r) {
        Setting s = new Setting(Setting.Kind.ACTION, key, label, tab, 0, 0, 0, 1);
        s.action = r; ALL.add(s); return s;
    }

    // ---- Combat ----
    public static final Setting KILLAURA = b("killaura", "KillAura", "Combat", false);
    public static final Setting KA_RANGE = n("ka_range", "Attack distance", "Combat", 3.5, 2.5, 6.0, 0.1);
    public static final Setting FOV = n("fov", "Target FOV", "Combat", 120, 30, 360, 5);
    public static final Setting LOWEST_HP = b("lowest_hp", "Target lowest HP", "Combat", false);
    public static final Setting TARGET_MOBS = b("target_mobs", "Target mobs", "Combat", false);
    public static final Setting THROUGH_WALLS = b("walls", "Target through walls", "Combat", false);
    public static final Setting AUTO_CRIT = b("autocrit", "Auto Crit", "Combat", false);
    public static final Setting AIM_ASSIST = b("aimassist", "Aim Assist", "Combat", false);
    public static final Setting AIM_SPEED = n("aim_speed", "Aim speed", "Combat", 6, 1, 25, 1);
    public static final Setting AIM_RANGE = n("aim_range", "Aim distance", "Combat", 4.5, 2.5, 8.0, 0.1);
    public static final Setting AIM_ONLY_ATTACK = b("aim_only_attack", "Aim only while attacking", "Combat", true);
    public static final Setting AUTO_TOTEM = b("autototem", "AutoTotem", "Combat", false);
    public static final Setting AUTO_GAPPLE = b("autogapple", "AutoGapple", "Combat", false);
    public static final Setting GAPPLE_HP = n("gapple_hp", "Gapple below HP", "Combat", 10, 2, 18, 1);
    public static final Setting AUTO_SWAP = b("autoswap", "AutoSwap weapon", "Combat", false);

    // ---- ESP ----
    public static final Setting BOX2D = b("box2d", "2D Box", "ESP", true);
    public static final Setting BOX3D = b("box3d", "3D Box", "ESP", false);
    public static final Setting SKELETON = b("skeleton", "Skeleton", "ESP", false);
    public static final Setting HEALTHBAR = b("healthbar", "Health Bar", "ESP", true);
    public static final Setting ITEM_ESP = b("itemesp", "Item ESP", "ESP", false);
    public static final Setting SPIN_ESP = b("spinesp", "Spin ESP", "ESP", false);
    public static final Setting ESP_RANGE = n("esp_range", "ESP distance", "ESP", 64, 16, 128, 4);

    // ---- HUD ----
    public static final Setting TARGET_HUD = b("targethud", "Target HUD", "HUD", true);
    public static final Setting CPS = b("cps", "CPS", "HUD", true);
    public static final Setting COMBO = b("combo", "Combo", "HUD", true);
    public static final Setting REACH = b("reach", "Reach", "HUD", true);
    public static final Setting KEYSTROKES = b("keystrokes", "Keystrokes", "HUD", true);
    public static final Setting COUNTERS = b("counters", "Totems / Gapples", "HUD", true);
    public static final Setting ARMOR = b("armor", "Armor status", "HUD", true);
    public static final Setting INV_COUNT = b("invcount", "Inventory count", "HUD", false);
    public static final Setting SHULKER = b("shulker", "Shulker preview", "HUD", true);

    // ---- Performance ----
    public static final Setting PRESET = a("preset", "Samsung A17 preset", "Perf", Settings::presetA17);
    public static final Setting RENDER_DIST = n("render_dist", "Render distance", "Perf", 6, 2, 16, 1).changed(Perf::apply);
    public static final Setting SIM_DIST = n("sim_dist", "Simulation distance", "Perf", 6, 5, 16, 1).changed(Perf::apply);
    public static final Setting ENTITY_DIST = n("entity_dist", "Entity distance", "Perf", 0.75, 0.5, 2.0, 0.25).changed(Perf::apply);
    public static final Setting PARTICLES_MIN = b("particles_min", "Minimal particles", "Perf", true).changed(Perf::apply);
    public static final Setting MAX_FPS = n("max_fps", "Max FPS", "Perf", 60, 30, 120, 10).changed(Perf::apply);
    public static final Setting SHADOWS_OFF = b("shadows_off", "No entity shadows", "Perf", true).changed(Perf::apply);
    public static final Setting FAST_GFX = b("fast_gfx", "Fast graphics", "Perf", true).changed(Perf::apply);

    private static void presetA17() {
        RENDER_DIST.value = 6; SIM_DIST.value = 6; ENTITY_DIST.value = 0.75;
        PARTICLES_MIN.on = true; PARTICLES_MIN.value = 1;
        MAX_FPS.value = 60;
        SHADOWS_OFF.on = true; SHADOWS_OFF.value = 1;
        FAST_GFX.on = true; FAST_GFX.value = 1;
        Perf.apply();
        save();
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("impulsevisual.properties");
    }

    public static void load() {
        Properties p = new Properties();
        try (var in = Files.newInputStream(file())) { p.load(in); } catch (IOException e) { return; }
        for (Setting s : ALL) {
            String v = p.getProperty(s.key);
            if (v == null) continue;
            try {
                if (s.kind == Setting.Kind.BOOL) { s.on = Boolean.parseBoolean(v); s.value = s.on ? 1 : 0; s.anim = s.on ? 1f : 0f; }
                else if (s.kind == Setting.Kind.NUM) s.value = Double.parseDouble(v);
            } catch (NumberFormatException ignored) { }
        }
    }

    public static void save() {
        Properties p = new Properties();
        for (Setting s : ALL) {
            if (s.kind == Setting.Kind.BOOL) p.setProperty(s.key, String.valueOf(s.on));
            else if (s.kind == Setting.Kind.NUM) p.setProperty(s.key, String.valueOf(s.value));
        }
        try (var out = Files.newOutputStream(file())) { p.store(out, "IMPULSE VISUAL"); } catch (IOException ignored) { }
    }

    private Settings() { }
}
